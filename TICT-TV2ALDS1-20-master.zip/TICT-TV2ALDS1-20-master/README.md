# ALDS

Welkom bij de Git van het Algoritme en Datastructuren vak aan de HU. Hier vind je de code en python notebooks voor de tutorials en eindopdracht van het vak. Bijbehorende reader en videos vind je op de canvas pagina.

## Installatie

Installeer de benodigde libraries met `pip install requirements.txt`. Tip: Het gebruik van een virtuele python environment zorgt ervoor dat de installatie niet conflitcteerd met andere python projecten op je systeem. Hiervoor kun je bijvoorbeeld [Anaconda](https://www.anaconda.com/products/distributionmarkd) gebruiken. Voor het werken met IPython Notebooks (.ipynb bestanden) kun je gebruik maken van VSCode, Pycharm, Jupyter of Spyder. 
